import Vue from 'vue';
import VueRouter from 'vue-router';

import Home from './modules/home/components/Home.vue'
import Register from './modules/register/components/Register.vue'
import ThankYou from './modules/register/components/thankyou.vue'
import MerchantDashboard from './modules/dashboard/components/MerchantDashboard.vue'

Vue.use(VueRouter);

const router = new VueRouter({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'home',
            component: Home
        },
        {
            path: '/register',
            name: 'register',
            component: Register
        },
        {
            path: '/thank-you',
            name: 'ThankYou',
            component: ThankYou
        },
        {
            path: '/merchant-dashboard',
            name: 'MerchantDashboard',
            component: MerchantDashboard
        }
    ]
});

export default router;
