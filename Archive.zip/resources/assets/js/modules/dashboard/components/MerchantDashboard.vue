<template>
    <div>Page is under constraction </div>
</template>
<script>
export default {
    name: 'MerchantDashboard'
}
</script>

