<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IdentificationTypes extends Model
{
    protected $table = "identification_types";
}
